<?php 
$OC_Version = array(15,0,0,10);
$OC_VersionString = '15.0.0';
$OC_Edition = '';
$OC_Channel = 'stable';
$OC_VersionCanBeUpgradedFrom = array (
  'nextcloud' => 
  array (
    '14.0' => true,
    '15.0' => true,
  ),
  'owncloud' => 
  array (
  ),
);
$OC_Build = '2018-12-10T10:24:53+00:00 3bb46a2accb9d3c8557b64f0ec6e088d94f9dd70';
$vendor = 'nextcloud';
